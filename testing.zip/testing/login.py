#
# import pytest
# from selenium import webdriver
# import time
# from selenium.webdriver.common.by import By
# # webdriver.Chrome()
# driver =webdriver.Chrome()
# driver.get("https://google.com/")
# driver.maximize_window()
# print(driver.title)
# print(driver.current_url)
# time.sleep(2)


from selenium import webdriver
import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.edge.service import Service
from selenium.webdriver.common.by import By


# webdriver.Chrome()
# serv_obj= Service(r"E:\SDET\testing\chromedriver.exe")
serv_obj= Service(r"E:\SDET\testing\msedgedriver.exe")
driver =webdriver.Edge(service=serv_obj)
driver.get("https://admin-demo.nopcommerce.com/")
driver.maximize_window()

txtbox_username_id= "Email"
txtbox_password_id= "Password"
button_submit = "//button[normalize-space()='Log in']"
usernametxt=driver.find_element(By.ID,txtbox_username_id)
usernametxt.clear()
usernametxt.send_keys("admin@yourstore.com")

passwordtxt=driver.find_element(By.ID,txtbox_password_id)
passwordtxt.clear()
passwordtxt.send_keys("admin")

driver.find_element(By.XPATH,button_submit)
print(driver.title)
print(driver.current_url)
time.sleep(2)