import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import os
import time


class TestClass:
    @pytest.mark.parametrize('user,pwd',[("Admin","admin123"),("adm","admin123"),("Admin","adm"),("adm","adm")])
    def test_login_chrome(self,user,pwd):
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        options = Options()
        options.add_argument("--log-level=3")  # INFO = 0, WARNING = 1, LOG_ERROR = 2, LOG_FATAL = 3
        options.add_experimental_option("excludeSwitches", ["enable-logging"])
        self.serv_obj= Service(r"E:\SDET\testing\chromedriver.exe")
        self.driver =webdriver.Chrome(service=self.serv_obj,options=options)
        # service = Service(log_path=os.devnull)
        self.driver.get("https://opensource-demo.orangehrmlive.com/")
        wait = WebDriverWait(self.driver, 10)
        wait.until(EC.presence_of_element_located((By.NAME, "username"))).send_keys(user)
        self.driver.find_element(By.NAME, "password").send_keys(pwd)
        self.driver.find_element(By.XPATH, "//button[normalize-space()='Login']").click()
        time.sleep(2)
        try:
            self.status=self.driver.find_element(By.XPATH,"//p[normalize-space()='Time at Work']").is_displayed()
            # Assertion
            assert self.status==True
            self.driver.close()
        except:
            self.driver.quit()
            assert False