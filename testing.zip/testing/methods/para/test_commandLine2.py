from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
import time
import os

class TestCLI:

    def test_logo(self,setup):
        self.driver = setup
        self.driver.get("https://opensource-demo.orangehrmlive.com/")
        wait = WebDriverWait(self.driver, 13)
        self.driver.maximize_window()
        try:
            # time.sleep(4)
            wait.until(EC.presence_of_element_located((By.XPATH, "//div[@class='orangehrm-login-branding']")))
            self.status=self.driver.find_element(By.XPATH, "//div[@class='orangehrm-login-branding']").is_displayed()

            self.driver.close()
            assert self.status == True
        except:
            self.driver.close()
            assert False


    def test_login(self,setup):
        self.driver=setup
        self.driver.get("https://opensource-demo.orangehrmlive.com/")
        wait = WebDriverWait(self.driver, 10)
        self.driver.maximize_window()
        wait.until(EC.presence_of_element_located((By.NAME, "username"))).send_keys("Admin")
        self.driver.find_element(By.NAME, "password").send_keys("admin123")
        self.driver.find_element(By.XPATH, "//button[normalize-space()='Login']").click()
        time.sleep(3)
        try:
            self.status = self.driver.find_element(By.XPATH, "//h6[normalize-space()='Dashboard']").is_displayed()
            # Assertion
            assert self.status == True
            self.driver.close()
        except:
            self.driver.close()
            assert False