import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options


@pytest.fixture()
def setup(browser):
    if browser == "chrome":
        from selenium.webdriver.chrome.service import Service
        options = Options()
        options.add_argument("--log-level=3")  # INFO = 0, WARNING = 1, LOG_ERROR = 2, LOG_FATAL = 3
        options.add_experimental_option("excludeSwitches", ["enable-logging"])
        serv_obj = Service(r"E:\SDET\testing\chromedriver.exe")
        driver = webdriver.Chrome(service=serv_obj, options=options)

    elif browser == "edge":
        from selenium.webdriver.edge.service import Service
        options = webdriver.EdgeOptions()
        options.add_argument("--log-level=3")  # hide warnings
        options.add_experimental_option("excludeSwitches", ["enable-logging"])
        serv_obj = Service(r"E:\SDET\testing\msedgedriver.exe")
        driver = webdriver.Edge(service=serv_obj, options=options)

    elif browser == "firefox":
        from selenium.webdriver.firefox.service import Service
        options = webdriver.FirefoxOptions()
        options.log.level = "fatal"
        serv_obj = Service(r"E:\SDET\testing\geckodriver.exe")
        driver = webdriver.Firefox(service=serv_obj, options=options)

    else:
        raise ValueError(f"Browser '{browser}' is not supported!")

    return driver

def pytest_addoption(parser):    #this will get the method from cli
    # parser.addoption("--browser")
    parser.addoption("--browser", action="store", default="chrome", help="Browser to run tests (chrome, edge, firefox)")

@pytest.fixture()
def browser(request):    # this will return the browser value to setup method
    return request.config.getoption("--browser")

#report customization HTML
@pytest.hookimpl(optionalhook=True)
def pytest_metadata(metadata):
    # Add your custom fields
    metadata["Project Name"] = "Orange HRM"
    metadata["Module Name"] = "Login Module"
    metadata["Tester Name"] = "skb"

    # Remove unwanted fields
    metadata.pop("JAVA_HOME", None)
    metadata.pop("Plugins", None)


#delete /modify evnvitonment
# @pytest.mark.optionalhook
# def pytest_metadata(metadata):
#     metadata.pop("JAVA_HOME", None)
#     metadata.pop("Plugins", None)