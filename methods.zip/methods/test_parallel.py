
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
import os
import time

# options = Options()
# options.add_argument("--log-level=3")   # INFO = 0, WARNING = 1, LOG_ERROR = 2, LOG_FATAL = 3
# options.add_experimental_option("excludeSwitches", ["enable-logging"])

import pytest

class TestLogin:
    def test_login_chrome(self):
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        options = Options()
        options.add_argument("--log-level=3")  # INFO = 0, WARNING = 1, LOG_ERROR = 2, LOG_FATAL = 3
        options.add_experimental_option("excludeSwitches", ["enable-logging"])
        self.serv_obj= Service(r"E:\SDET\testing\chromedriver.exe")
        self.driver =webdriver.Chrome(service=self.serv_obj,options=options)
        # service = Service(log_path=os.devnull)
        self.driver.get("https://opensource-demo.orangehrmlive.com/")
        wait = WebDriverWait(self.driver, 10)
        wait.until(EC.presence_of_element_located((By.NAME, "username"))).send_keys("Admin")
        self.driver.find_element(By.NAME, "password").send_keys("admin123")
        self.driver.find_element(By.XPATH, "//button[normalize-space()='Login']").click()

        # Assertion
        assert "OrangeHRM" in self.driver.title
        assert self.driver.title == "OrangeHRM"
        self.driver.quit()

    def test_login_edge(self):
        from selenium import webdriver
        from selenium.webdriver.edge.service import Service
        options = webdriver.EdgeOptions()
        options.add_argument("--log-level=3")  # hide warnings
        options.add_experimental_option("excludeSwitches", ["enable-logging"])
        self.serv_obj = Service(r"E:\SDET\testing\msedgedriver.exe")
        self.driver = webdriver.Edge(service=self.serv_obj,options=options)
        # service = Service(log_path=os.devnull)
        self.driver.get("https://opensource-demo.orangehrmlive.com/")
        wait = WebDriverWait(self.driver, 10)
        wait.until(EC.presence_of_element_located((By.NAME, "username"))).send_keys("Admin")
        self.driver.find_element(By.NAME, "password").send_keys("admin123")
        time.sleep(2)
        self.driver.find_element(By.XPATH, "//button[normalize-space()='Login']").click()

        # Assertion
        assert "OrangeHRM" in self.driver.title
        assert self.driver.title == "OrangeHRM"
        self.driver.quit()

    def test_login_firefox(self):
        from selenium import webdriver
        from selenium.webdriver.firefox.service import Service
        options = webdriver.FirefoxOptions()
        options.log.level = "fatal"
        self.serv_obj= Service(r"E:\SDET\testing\geckodriver.exe")
        self.driver =webdriver.Firefox(service=self.serv_obj,options=options)
        # service = Service(log_path=os.devnull)
        self.driver.get("https://opensource-demo.orangehrmlive.com/")
        wait = WebDriverWait(self.driver, 10)
        wait.until(EC.presence_of_element_located((By.NAME, "username"))).send_keys("Admin")
        self.driver.find_element(By.NAME, "password").send_keys("admin123")
        time.sleep(2)
        self.driver.find_element(By.XPATH, "//button[normalize-space()='Login']").click()

        # Assertion
        assert "OrangeHRM" in self.driver.title
        assert self.driver.title == "OrangeHRM"
        self.driver.quit()