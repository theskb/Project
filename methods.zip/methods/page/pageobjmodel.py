from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class LoginPage:
    #Locators
    txtbox_username_id= "Email"
    txtbox_password_id= "Password"
    button_submit = "//button[normalize-space()='Log in']"

    #Constructor
    def __init__(self,driver):
        self.driver=driver

    #actions
    def setUserName(self,username):
        usernametxt=self.driver.find_element(By.ID,self.txtbox_username_id)
        usernametxt.clear()
        usernametxt.send_keys(username)

    def setPassword(self,password):
        passwordtxt=self.driver.find_element(By.ID,self.txtbox_password_id)
        passwordtxt.clear()
        passwordtxt.send_keys(password)

    def clickLogin(self):
        self.driver.find_element(By.XPATH,self.button_submit)