import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from pageobjmodel import LoginPage


class TestLogin:
    def test_login(self):
        options = Options()
        options.add_argument("--log-level=3")  # INFO = 0, WARNING = 1, LOG_ERROR = 2, LOG_FATAL = 3
        options.add_experimental_option("excludeSwitches", ["enable-logging"])
        serv_obj=Service(r"E:\SDET\testing\chromedriver.exe")
        self.driver = webdriver.Chrome(service=serv_obj, options=options)
        self.driver.get("https://admin-demo.nopcommerce.com/")
        self.driver.maximize_window()

        self.lp=LoginPage(self.driver)
        self.lp.setUserName("admin@yourstore.com")
        self.lp.setPassword("admin")
        self.lp.clickLogin()

        self.act_title=self.driver.title
        self.driver.close()
        assert self.act_title == "nopCommerce demo store. Login"